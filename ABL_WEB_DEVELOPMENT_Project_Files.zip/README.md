# Web Development Activity-Based Learning (ABL)

## Student Details
- Name: [Enter your name]
- Roll Number: [Enter your roll number]
- Branch: [Enter your branch]
- Section: [Enter your section]

## Selected Case Studies
1. Personal Portfolio Website
2. College Admissions Website
3. Online Learning Website

## Technologies Used
- HTML
- CSS

## Project Structure
Each case study folder contains:
- `index.html` - webpage structure
- `style.css` - webpage design and formatting
- `screenshot.png` - webpage preview

## How to Run
1. Download or clone this repository.
2. Open any case study folder.
3. Open `index.html` in a web browser.
4. Edit `style.css` to change colors, spacing, borders, and fonts.

## Conclusion
These three beginner-level webpages demonstrate the use of basic HTML elements, links, headings, paragraphs, lists, and CSS styling.
